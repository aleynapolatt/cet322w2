﻿namespace AzureFunctionsTodo.Models
{
    public class TodoCreateModel
    {
        public string TaskDescription { get; set; }
    }
}